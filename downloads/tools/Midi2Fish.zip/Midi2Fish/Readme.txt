Midi to Fishsong Converter
Installation Instructions
 
Step 1 � Unzip the package
 
Since you�re reading this, you already have.
 
Step 2 � Download and Install a Java Runtime Environment
 
To use Midi2Fish, you need to have Java version 1.4 or newer (previous versions may work but have not been tested). Refer to http://java.sun.com/j2se/1.4/ for the latest release. At a minimum, you will need to install J2SE JRE (Java Run-time Environment).
 
Step 3 � Run the program
 
You can try to double-click the Midi2Fish.jar file. If you�re lucky it will launch the Midi2Fish application. If not, open a command window, change to the directory containing the file �Midi2Fish.jar�, and type the following command:
 
javaw.exe �jar Midi2Fish.jar
 
Note that the executable (javaw.exe) must be in your current Path. You can add the JRE bin directory into your path by going to your �My Computer� icon, right-click, choose Properties. On the Advanced tab, click on Environment Variables. Find the �Path� variable and add the full path to Java�s bin directory.
 
 
Additional Notes and Links
Included in the archive is an example MIDI file for you to work with. You can examine the Raw version and the Fishsong Ready version to see how to structure the midi file so it sounds moderately like the original after it is converted.
 
I recommend that you use MidiNotate Composer or Musician (available from http://www.notation.com/) to reformat and structure your MIDI files. Specifically, I use Track -> Merge Tracks� and Track -> Delete Track� for this purpose.
 
You can use the TonePlayer to listen to the converted songs. Download it from http://insaniquariumguide.com/pages/songinfo.html
 
Have fun!
 
 
 
Copyright (C) 2005 Dennis Lockshine <lockshine@comcast.net>. All rights reserved.
USE AT YOUR OWN RISK. This program is distributed WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
