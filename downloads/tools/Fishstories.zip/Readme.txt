Story Editor for Insaniquarium Deluxe


This program allows you to edit the stories for the pets/aliens in
Challenge mode.


Usage:
 Use the scroll-bar to scroll through each story. Change the pet's
 name and description to your liking. Once you've finished editing
 all the stories, click 'Apply Changes' and exit the program.

 It is recommended that you use the self-explanatory backup buttons
 to backup your executable before making any changes, so you can
 restore it to its original form rather than reinstalling.


NOTE:
 This program only works with the early PopCap Games version of
 Insaniquarium Deluxe. You will receive an error message if you have
 a different version.


Please post any questions on my forum:
 http://www.samssite.co.nr/Forum


-Sam Palmer
http://www.samssite.co.nr/