You can specify 3 different lines of simultaneous notes.  Also you can play two notes at the same time in the same line by playing one note with duration 0 and the second note with the actual duration that you want.

The format of each note is the letter (a,b,c,d,e,f,g [or r for rest]) followed by an optional # or b for sharp or flat followed by the octave (defaults to 4 if not specified).  The octave starts with c, so b3 is followed by c4.  The second part of a note is its duration.  You can either put in a manual time or you can use the following:

z - 64th note
t - 32nd note
s - 16th note
e - 8th note
q - quarter note
h - half note
w - whole note

followed by an optional 'd' for dot

So ed would be a dotted eighth note (you could have edd for a double-dotted eighth note)

followed by an optional + and another duration to do a tie... so

q+e would be a quarter note tied to an eighth note.

Here are some playing commands:

*line sets the current line (you can have multiple lines playing at the same time)
*speed sets the speed (can be a decimal)
*volume sets the volume (# between 0 and 1)
*shift shifts all the lines by the specified number of half steps
*localshift shifts the current line by the specified number of half steps
*off skips everything until a subsequent *on command
*rest inserts a rest in the current line which catches it up to the specified line (for instance *rest 2 would catch the current line up with line 2... this is useful if one line isn't playing for a while but you don't want to keep track of how many rests to insert)
